require("shelljs/global");
var lwip = require("lwip");
var path = require("path");
var fs = require("fs");
var readlineSync = require('readline-sync');
var options = require("./options.js");

var size = options.size;
var imagesDirectory = options.imagesDirectory;

var images = ls(`${imagesDirectory}/*.JPG`);
echo(images);

var thumbsDirectory = path.join(imagesDirectory, "thumbs");
if (fs.existsSync(thumbsDirectory)) {
  var response = readlineSync.keyInYN(`The ${thumbsDirectory} exists, would you like to wipe it out and continue?`);
  if (!response) {
    echo("Aborting termination of thumbnails");
    exit();
  }
  rm("-rf", thumbsDirectory);
}
mkdir(thumbsDirectory);

images.forEach(imageFile => {
  lwip.open(imageFile, (error, image) => {
    var fileName = path.basename(imageFile);
    var thumbFile = path.join(thumbsDirectory, fileName);

    image.batch()
      .contain(size, size, "white")
      .writeFile(thumbFile, err => {
        if (err) {
          console.error(err);
          return;
        }
        echo(`${thumbFile} done`);
      });

  });
});