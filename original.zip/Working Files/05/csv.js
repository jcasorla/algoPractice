require("shelljs/global");
var csv = require('csv');
var _ = require('lodash');
var moment = require("moment");

var csvData = cat("table.csv");

function average(values) {
  var sum = _.sum(values);
  var count = values.length;
  return sum / count;
}

csv.parse(csvData, (error, rows) => {
  var dataRows = rows.slice(1);

  var weeklyAverages = _(dataRows)
    .groupBy(r => moment(r[0]).week())
    .map((values, key) => {
      var closingPrices = _(values).map(v => v[4]).map(parseFloat).value();
      return{
        key: values[0][0],
        averageClosingPrice: average(closingPrices)
      }
    })
    .value();

  echo(weeklyAverages);




  //echo(`Average: ${average(closingPrices)}`);
});