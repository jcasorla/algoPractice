## Linked List
Check out linked.ts or ll.c.

For nvim lsp purposes there is an empty tsconfig and a simple cmake to generate
compile_commands.json.

### Gimp Walkthrough - from video

* What is a linked list?
* What is a queue
* What is a stack

* Implementing
  * Queue
    * What is it used for?
    * How to insert
    * How to remove

  * Stack
    * What is it used for?
    * How to insert?
    * How to remove?

  * Doubly linked list
    * What is it used for?
    * How to insert?
    * How to remove?


