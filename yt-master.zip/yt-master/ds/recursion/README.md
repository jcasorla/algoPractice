## Recursion

### Getting started
1. you must `npm i` in the root of the yt project.
2. npx ts-node src/recursion.ts

### Writing your own
ensure that the `runYours` variable is set to `true` in the recursion-values.ts file.
This will cause the program to run recurseMaze instead of the logging version.

You should fill this in according to the video that is on YT (made this before
I made the YT video so I don't know the link currently).

#### Altering the maze and values.
You can edit the directions that are chosen by the maze solver and the maze
itself by going to the recursion-value.ts file and setting new values.
